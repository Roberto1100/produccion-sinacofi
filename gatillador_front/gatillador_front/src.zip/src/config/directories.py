# Directorio para Logs
LOGS_DIRECTORY = r'C:\Users\Pancho\Documents\Programacion\Axway\gatillador_front\gatillador_front\Directorios\LOGS_DIRECTORY'


# Directorio de trabajo
FILES_DIRECTORY = r'C:\Users\Pancho\Documents\Programacion\Axway\gatillador_front\gatillador_front\Directorios\FILES_DIRECTORY'

# Directorio archivos validados
VALIDATED_FILES_DIRECTORY = r'C:\Users\Pancho\Documents\Programacion\Axway\gatillador_front\gatillador_front\Directorios\VALIDATED_FILES_DIRECTORY'