ORA_CONFIG_DIRECTORY = r"C:\Users\Pancho\Documents\Programacion\Axway\gatillador_front\ORA_CONFIG"
CREDENTIAL_ALIAS = "Desarrollo"